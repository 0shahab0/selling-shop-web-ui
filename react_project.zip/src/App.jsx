import React from 'react'
import { Outlet, NavLink, useNavigate } from 'react-router-dom'
import { useStore } from './contexts/StoreContext.jsx'
import ChatDock from './components/ChatDock.jsx'
import AuthModal from './components/AuthModal.jsx'

export default function App() {
  const {theme, setTheme, currentUser, signInAsDemo, cart, t } = useStore()
  const navigate = useNavigate()

  return (
    <div className={theme === 'dark' ? 'dark' : ''}>
      <div className="min-h-screen bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100">
        <header className="sticky top-0 z-40 backdrop-blur bg-white/70 dark:bg-neutral-900/70 border-b border-neutral-200 dark:border-neutral-800">
          <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-3">
            <div onClick={()=>navigate('/')} className="font-extrabold text-xl cursor-pointer">
              <span className="text-emerald-600">Green</span>Market
            </div>

            <div className="flex-1 mx-4">
              <input placeholder="Search products..." className="input" onKeyDown={(e)=>{
                if(e.key==='Enter') navigate(`/explore?q=${encodeURIComponent(e.currentTarget.value)}`)
              }} />
            </div>

            <nav className="hidden md:flex items-center gap-2">
              <NavLink to="/" className="btn btn-ghost">{t('home')}</NavLink>
              <NavLink to="/explore" className="btn btn-ghost">{t('explore')}</NavLink>
              <NavLink to="/upload" className="btn btn-ghost">{t('upload')}</NavLink>
              <NavLink to="/about" className="btn btn-ghost">{t('about')}</NavLink>
              <NavLink to="/settings" className="btn btn-ghost">{t('settings')}</NavLink>
              <NavLink to="/cart" className="btn btn-ghost">Cart ({cart.reduce((a,c)=>a+c.qty,0)})</NavLink>
            </nav>

            <div className="flex items-center gap-2">
              <button
                onClick={()=> setTheme(theme==='dark'?'light':'dark')}
                className="btn btn-ghost"
                title="Toggle theme"
              >
                {theme==='dark'?'🌙':'☀️'}
              </button>

              {!currentUser ? (
                <button onClick={signInAsDemo} className="btn btn-primary">{t('createAccount')}</button>
              ) : (
                <div className="flex items-center gap-2">
                  <img src={currentUser.avatar} className="w-8 h-8 rounded-full" />
                  <span className="text-sm">{currentUser.name}</span>
                </div>
              )}
            </div>
          </div>
          <ChatDock />
          <AuthModal />
        </header>

        <main className="max-w-7xl mx-auto px-4 py-6">
          <Outlet />
        </main>

        <footer className="border-t border-neutral-200 dark:border-neutral-800 py-8 text-center text-sm opacity-70">
          © {new Date().getFullYear()} GreenMarket — UI demo
        </footer>
      </div>
    </div>
  )
}
