import React from 'react'
import ReactDOM from 'react-dom/client'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import './index.css'
import App from './App.jsx'
import { StoreProvider } from './contexts/StoreContext.jsx'
import Home from './pages/Home.jsx'
import Explore from './pages/Explore.jsx'
import Cart from './pages/Cart.jsx'
import Upload from './pages/Upload.jsx'
import About from './pages/About.jsx'
import Settings from './pages/Settings.jsx'
import Item from './pages/Item.jsx'

const router = createBrowserRouter([
  {
    path: '/', element: <App />,
    children: [
      { index: true, element: <Home /> },
      { path: 'explore', element: <Explore /> },
      { path: 'cart', element: <Cart /> },
      { path: 'upload', element: <Upload /> },
      { path: 'about', element: <About /> },
      { path: 'settings', element: <Settings /> },
      { path: 'item/:id', element: <Item /> },
    ]
  }
])

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <StoreProvider>
      <RouterProvider router={router} />
    </StoreProvider>
  </React.StrictMode>
)
