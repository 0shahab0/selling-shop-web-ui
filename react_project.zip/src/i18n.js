const dict={
  en:{
    welcome:'Welcome',
    cart:'Cart',
    settings:'Settings'
  },
  fa:{
    welcome:'خوش آمدید',
    cart:'سبد خرید',
    settings:'تنظیمات'
  }
}
export default function t(lang,key){ return dict[lang]?.[key]||key }
