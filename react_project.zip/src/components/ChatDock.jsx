import React, { useState } from 'react'
import { useStore } from '../contexts/StoreContext.jsx'
import ChatWindow from './ChatWindow.jsx'

export default function ChatDock(){
  const { chats } = useStore()
  const [active, setActive] = useState(null)
  const ids = Object.keys(chats)

  if(ids.length === 0) {
    return (
      <div className="border-t border-neutral-200 dark:border-neutral-800">
        <div className="max-w-7xl mx-auto px-4 py-2 text-sm opacity-70">
          Start a conversation by clicking <strong>Chat</strong> on any product.
        </div>
      </div>
    )
  }

  return (
    <div className="border-t border-neutral-200 dark:border-neutral-800">
      <div className="max-w-7xl mx-auto px-4 py-2">
        <div className="flex items-center gap-2 overflow-x-auto">
          {ids.map(id => {
            const thread = chats[id]
            const partner = thread?.partner // ✅ safe check
            return (
              <button
                key={id}
                onClick={() => setActive(active === id ? null : id)}
                className={
                  "flex items-center gap-2 px-3 py-1 rounded-full border " +
                  (active === id
                    ? "bg-emerald-600 text-white border-emerald-600"
                    : "bg-white dark:bg-neutral-900 border-neutral-200 dark:border-neutral-700")
                }
              >
                {partner ? (
                  <img
                    src={partner.avatar}
                    alt={partner.name || "User"}
                    className="w-6 h-6 rounded-full"
                  />
                ) : (
                  // ✅ fallback avatar if no partner
                  <div className="w-6 h-6 rounded-full bg-gray-300" />
                )}
                <span className="text-sm">
                  {partner?.name || "Unknown"}
                </span>
              </button>
            )
          })}
        </div>
      </div>
      {active && <ChatWindow partnerId={active} onClose={() => setActive(null)} />}
    </div>
  )
}
