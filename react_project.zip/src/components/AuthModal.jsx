import React, { useState } from 'react'
import { useStore } from '../contexts/StoreContext.jsx'

export default function AuthModal(){
  const { authOpen, setAuthOpen, register, login, t } = useStore()
  const [mode, setMode] = useState('login') // 'login' | 'signup'
  const [name, setName] = useState('')

  if(!authOpen) return null

  function submit(e){
    e.preventDefault()
    if(mode==='signup'){ register({ name: name.trim() }) }
    else { login({ name: name.trim() }) }
    setAuthOpen(false)
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/50" onClick={()=>setAuthOpen(false)} />
      <div className="relative bg-white dark:bg-neutral-900 rounded-2xl shadow-xl w-full max-w-md p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold">{mode==='signup' ? 'Sign Up' : 'Login'}</h2>
          <button className="btn btn-ghost" onClick={()=>setAuthOpen(false)}>✕</button>
        </div>
        <div className="flex gap-2 mb-4">
          <button className={"btn " + (mode==='login'?'btn-primary':'btn-ghost')} onClick={()=>setMode('login')}>Login</button>
          <button className={"btn " + (mode==='signup'?'btn-primary':'btn-ghost')} onClick={()=>setMode('signup')}>Sign Up</button>
        </div>
        <form onSubmit={submit} className="space-y-3">
          <div>
            <label className="block text-sm mb-1">Name</label>
            <input className="input" value={name} onChange={e=>setName(e.target.value)} placeholder="Your name" required />
          </div>
          <button className="btn btn-primary w-full" type="submit">{mode==='signup' ? 'Create Account' : 'Login'}</button>
        </form>
      </div>
    </div>
  )
}
