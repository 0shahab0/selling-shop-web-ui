import GuardModal from './GuardModal.jsx'
import React, { useState } from 'react'
import { useStore } from '../contexts/StoreContext.jsx'

export default function UploadDrawer(){
  const { addProduct, currentUser, t } = useStore()
  const [open, setOpen] = useState(false)
  const [warnOpen, setWarnOpen] = useState(false) // ✅ added state for warning modal
  const [form, setForm] = useState({
    title: '', price: '', condition: 'new', category: 'general',
    description: '', image: '', imageFile: null, preview: ''
  })

  function handleFile(e){
    const file = e.target.files?.[0]
    if(!file) return
    const reader = new FileReader()
    reader.onload = () => {
      setForm(f => ({ ...f, imageFile: file, preview: reader.result }))
    }
    reader.readAsDataURL(file)
  }

  function submit(e){
    e.preventDefault()
    const price = parseFloat(form.price || '0')
    const p = { ...form, price, image: form.preview || '' }
    const created = addProduct(p)
    setOpen(false)
    setForm({ title:'', price:'', condition:'new', category:'general', description:'', image:'', imageFile:null, preview:'' })
  }

  return (
    <div>
      <button 
        className="btn btn-primary" 
        onClick={() => currentUser ? setOpen(true) : setWarnOpen(true)}
      >
        {t('newItem')}
      </button>

      {open && (
        <div className="fixed inset-0 z-40">
          <div className="absolute inset-0 bg-black/50" onClick={()=>setOpen(false)} />
          <div className="absolute right-0 top-0 h-full w-full max-w-md bg-white dark:bg-neutral-900 p-6 overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold">{t('uploadItem')}</h2>
              <button className="btn btn-ghost" onClick={()=>setOpen(false)}>✕</button>
            </div>
            <form className="space-y-4" onSubmit={submit}>
              <div>
                <label className="block text-sm mb-1">Title</label>
                <input 
                  className="input" 
                  value={form.title} 
                  onChange={e=>setForm(f=>({...f, title:e.target.value}))} 
                  placeholder="e.g., Retro Camera" 
                  required 
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm mb-1">{'Price'}</label>
                  <input 
                    className="input" 
                    type="number" 
                    min="0" 
                    step="0.01" 
                    value={form.price} 
                    onChange={e=>setForm(f=>({...f, price:e.target.value}))} 
                    placeholder="0.00" 
                    required 
                  />
                </div>
                <div>
                  <label className="block text-sm mb-1">{'Condition'}</label>
                  <select 
                    className="input" 
                    value={form.condition} 
                    onChange={e=>setForm(f=>({...f, condition:e.target.value}))}
                  >
                    <option value="new">New</option>
                    <option value="used">Used</option>
                    <option value="refurbished">Refurbished</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm mb-1">{'Category'}</label>
                  <input 
                    className="input" 
                    value={form.category} 
                    onChange={e=>setForm(f=>({...f, category:e.target.value}))} 
                    placeholder="e.g., electronics" 
                  />
                </div>
                <div>
                  <label className="block text-sm mb-1">{'Image'}</label>
                  <input className="input" type="file" accept="image/*" onChange={handleFile} />
                </div>
              </div>
              {form.preview && (
                <div className="rounded-lg overflow-hidden border border-neutral-200 dark:border-neutral-800">
                  <img src={form.preview} alt="preview" className="w-full h-48 object-cover" />
                </div>
              )}
              <div>
                <label className="block text-sm mb-1">{'Details / Notes'}</label>
                <textarea 
                  className="textarea h-28" 
                  value={form.description} 
                  onChange={e=>setForm(f=>({...f, description:e.target.value}))} 
                  placeholder="e.g., scratches, age, accessories, warranty, etc." 
                />
              </div>
              <div className="pt-2 flex gap-3">
                <button className="btn btn-primary" type="submit">{t('save')}</button>
                <button className="btn btn-ghost" type="button" onClick={()=>setOpen(false)}>{t('cancel')}</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ✅ Guard modal now works */}
      <GuardModal open={warnOpen} onClose={()=>setWarnOpen(false)} message={t('warnUpload')} />
    </div>
  )
}
