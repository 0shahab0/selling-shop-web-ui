import React, { useRef, useState, useEffect } from 'react'
import { useStore } from '../contexts/StoreContext.jsx'

export default function ChatWindow({ partnerId, onClose }){
  const { chats, sendMessage, users, currentUser } = useStore()
  const me = currentUser || users[1]
  const thread = chats[partnerId]
  const [text, setText] = useState('')
  const endRef = useRef(null)

  useEffect(()=>{ endRef.current?.scrollIntoView({behavior:'smooth'}) }, [thread])

  if(!thread) return null

  return (
    <div className="max-w-7xl mx-auto px-4 pb-2">
      <div className="card p-0 overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-neutral-200 dark:border-neutral-800">
          <div className="flex items-center gap-3">
            <img src={thread.partner.avatar} className="w-8 h-8 rounded-full" />
            <div>
              <div className="font-semibold">{thread.partner.name}</div>
              <div className="text-xs opacity-70">Private chat</div>
            </div>
          </div>
          <button className="btn btn-ghost" onClick={onClose}>Close</button>
        </div>

        <div className="h-72 overflow-y-auto p-4 space-y-2 bg-neutral-50 dark:bg-neutral-950">
          {thread.messages.map(m => {
            const mine = m.from === me.id
            return (
              <div key={m.id} className={"flex " + (mine?'justify-end':'justify-start')}>
                <div className={(mine?'bg-emerald-600 text-white':'bg-white dark:bg-neutral-900 text-neutral-900 dark:text-neutral-100') + " px-3 py-2 rounded-2xl max-w-[70%] shadow"}>
                  <div className="text-sm whitespace-pre-wrap">{m.text}</div>
                </div>
              </div>
            )
          })}
          <div ref={endRef} />
        </div>

        <form className="p-3 flex items-center gap-2" onSubmit={(e)=>{
          e.preventDefault()
          sendMessage(partnerId, text)
          setText('')
        }}>
          <input className="input" placeholder="Write a message..." value={text} onChange={e=>setText(e.target.value)} />
          <button className="btn btn-primary" type="submit">Send</button>
        </form>
      </div>
    </div>
  )
}
