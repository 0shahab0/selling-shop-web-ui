import GuardModal from "./GuardModal";
import React, { useState } from 'react'
GuardModal.jsx
import { Link } from 'react-router-dom'
import ConditionBadge from './ConditionBadge.jsx'
import { useStore } from '../contexts/StoreContext.jsx'

export default function ProductCard({ p }){
  const [warnOpen, setWarnOpen] = useState(false)
  const {users, addToCart, startChatWith, currentUser, t } = useStore()
  const seller = users.find(u=>u.id===p.sellerId) || { name: 'Seller', avatar: 'https://i.pravatar.cc/80' }
  return (
    <div className="card overflow-hidden group">
      <div className="relative">
        <img src={p.image} className="w-full h-48 object-cover transition group-hover:scale-105" />
        <div className="absolute top-2 left-2 flex gap-2">
          <ConditionBadge condition={p.condition} />
          {p.featured && <span className="badge bg-emerald-600 text-white">featured</span>}
        </div>
      </div>
      <div className="p-4 space-y-3">
        <Link to={`/item/${p.id}`} className="block font-semibold text-lg hover:underline">{p.title}</Link>
        <div className="flex items-center justify-between">
          <div className="text-emerald-600 font-bold">${p.price.toFixed(2)}</div>
          <div className="flex items-center gap-2 text-sm opacity-80">
            <img src={seller.avatar} className="w-6 h-6 rounded-full" />
            <span>{seller.name}</span>
          </div>
        </div>
        <div className="flex gap-2 pt-2">
          <button className="btn btn-primary flex-1" onClick={()=> currentUser ? addToCart(p.id,1) : setWarnOpen(true)}>{t('addToCart')}</button>
          <button className="btn btn-ghost" onClick={()=>startChatWith(seller.id)}>{t('chat')}</button>
        </div>
      </div>
      <GuardModal open={warnOpen} onClose={()=>setWarnOpen(false)} message={t('warnCart')} />
    </div>
  )
}
