import React from 'react'
import ProductCard from './ProductCard.jsx'

export default function ItemGrid({ items }){
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {items.map(p => <ProductCard key={p.id} p={p} />)}
    </div>
  )
}
