import React from 'react'

export default function ConditionBadge({ condition }){
  const map = { new: 'badge-new', used: 'badge-used', broken: 'badge-broken', old: 'badge-old' }
  const cls = map[condition] || 'badge-old'
  return <span className={['badge', cls].join(' ')}>{condition}</span>
}
