import React, { createContext, useContext, useEffect, useMemo, useState } from 'react'

const translations = {
  en: {
    app_name: "GreenMarket",
    Home: "Home",
    Explore: "Explore",
    Upload: "Upload",
    About: "About",
    Settings: "Settings",
    Cart: "Cart",
    Featured: "Featured",
    featured_badge: "featured",
    hero_title: "Your multi‑store marketplace, ",
    hero_title_em: "elevated",
    hero_desc: "Upload items with full details, show condition & price, and chat privately with buyers — all in one sleek interface.",
    explore_cta: "Explore",
    your_cart: "Your Cart",
    remove: "Remove",
    checkout: "Checkout",
    add_to_cart: "Add to Cart",
    add_to_cart_lower: "Add to cart",
    chat: "Chat",
    chat_with_seller: "Chat with Seller",
    item_not_found: "Item not found.",
    seller: "Seller",
    theme: "Theme",
    theme_hint: "Light or Dark (green accent)",
    light: "Light",
    dark: "Dark",
    account: "Account",
    logout: "Sign out",
    login_signup: "Signup/Login",
    language: "Language",
    english: "English",
    farsi: "Farsi",
    cond_new: "New",
    cond_used: "Used",
    cond_broken: "Broken",
    cond_old: "Old",
  },
  fa: {
    app_name: "بازارِ سبز",
    Home: "خانه",
    Explore: "کاوش",
    Upload: "آپلود",
    About: "درباره",
    Settings: "تنظیمات",
    Cart: "سبد خرید",
    Featured: "ویژه",
    featured_badge: "ویژه",
    hero_title: "بازار چندفروشه‌ی شما، ",
    hero_title_em: "ارتقایافته",
    hero_desc: "کالاها را با جزئیات کامل بارگذاری کنید، وضعیت و قیمت را نشان دهید و به‌صورت خصوصی با خریداران چت کنید — همه در یک رابط شیک.",
    explore_cta: "کاوش",
    your_cart: "سبد خرید شما",
    remove: "حذف",
    checkout: "تسویه",
    add_to_cart: "افزودن به سبد",
    add_to_cart_lower: "افزودن به سبد",
    chat: "چت",
    chat_with_seller: "گفتگو با فروشنده",
    item_not_found: "کالا پیدا نشد.",
    seller: "فروشنده",
    theme: "پوسته",
    theme_hint: "روشن یا تیره (با تاکید سبز)",
    light: "روشن",
    dark: "تیره",
    account: "حساب",
    logout: "خروج",
    login_signup: "ثبت‌نام/ورود",
    language: "زبان",
    english: "انگلیسی",
    farsi: "فارسی",
    cond_new: "نو",
    cond_used: "دست‌دوم",
    cond_broken: "خراب",
    cond_old: "قدیمی",
  }
}

const I18n = createContext(null)
export const useI18n = () => useContext(I18n)

export function I18nProvider({ children }){
  const [lang, setLang] = useState(()=> localStorage.getItem('lang') || 'en')

  useEffect(()=>{
    localStorage.setItem('lang', lang)
    document.documentElement.dir = (lang === 'fa') ? 'rtl' : 'ltr'
  },[lang])

  const t = useMemo(()=>{
    return (key)=> (translations[lang] && translations[lang][key]) ?? translations['en'][key] ?? key
  },[lang])

  const value = useMemo(()=>({ lang, setLang, t }), [lang, setLang, t])

  return <I18n.Provider value={value}>{children}</I18n.Provider>
}
