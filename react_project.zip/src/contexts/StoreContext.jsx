import React, { createContext, useContext, useEffect, useMemo, useState } from 'react'
import { nanoid } from 'nanoid/non-secure'

const Store = createContext(null)
export const useStore = () => useContext(Store)

const LS_KEY = 'greenmarket_state_v2'

export function StoreProvider({ children }) {
  const [theme, setTheme] = useState(() => localStorage.getItem('theme') || 'light')
  const [locale, setLocale] = useState(() => localStorage.getItem('locale') || 'en')
  const [currentUser, setCurrentUser] = useState(null)
  const [users, setUsers] = useState([])
  const [products, setProducts] = useState([])
  const [cart, setCart] = useState([])
  const [chats, setChats] = useState({})
  const [authOpen, setAuthOpen] = useState(false)

  // persist theme/locale
  useEffect(()=>{ localStorage.setItem('theme', theme)},[theme])
  useEffect(()=>{ localStorage.setItem('locale', locale)},[locale])

  // basic i18n dictionary (labels kept as-is by default; Persian shows runtime translations)
  const dict = {
  en: {
    theme: 'Theme',
    lightOrDark: 'Light or Dark (green accent)',
    light: 'Light',
    dark: 'Dark',
    account: 'Account',
    notSignedIn: 'Not signed in',
    signedInAs: 'Signed in as',
    demoLogin: 'Create Account',
    changeAccount: 'Change Account',
    language: 'Language',
    english: 'English',
    farsi: 'Farsi',
    home: 'Home',
    explore: 'Explore',
    upload: 'Upload',
    cartLbl: 'Cart',
    about: 'About',
    settings: 'Settings',
    createAccount: 'Create Account',
    addToCart: 'Add to Cart',
    chat: 'Chat',
    chatWithSeller: 'Chat with Seller',
    newItem: 'New Item',
    uploadItem: 'Upload Item',
    save: 'Save',
    cancel: 'Cancel',
    warnUpload: 'Please login or sign up before uploading.',
    warnCart: 'Please login or sign up before adding items to cart.'
  },
  fa: {
    theme: 'پوسته',
    lightOrDark: 'روشن یا تیره (سبز)',
    light: 'روشن',
    dark: 'تیره',
    account: 'حساب کاربری',
    notSignedIn: 'وارد نشده‌اید',
    signedInAs: 'وارد شده به نام',
    demoLogin: 'ورود',
    changeAccount: 'تغییر حساب',
    language: 'زبان',
    english: 'انگلیسی',
    farsi: 'فارسی',
    home: 'خانه',
    explore: 'جستجو',
    upload: 'آپلود',
    cartLbl: 'سبد خرید',
    about: 'درباره',
    settings: 'تنظیمات',
    createAccount: 'ساخت حساب',
    addToCart: 'افزودن به سبد',
    chat: 'چت',
    chatWithSeller: 'گفتگو با فروشنده',
    newItem: 'آیتم جدید',
    uploadItem: 'آپلود آیتم',
    save: 'ذخیره',
    cancel: 'انصراف',
    warnUpload: 'لطفاً قبل از آپلود وارد شوید یا ثبت‌نام کنید.',
    warnCart: 'لطفاً قبل از افزودن به سبد وارد شوید یا ثبت‌نام کنید.'
  }
}
const t = (k) => (dict[locale] && dict[locale][k]) || k

  // products
  function addProduct(p){
    const id = nanoid(8)
    const prod = { id, ...p }
    setProducts(prev => [prod, ...prev])
    return prod
  }
  const productById = (id) => products.find(p=>p.id===id)

  // cart
  function addToCart(productId, qty=1){ setCart(c=>[...c, { id: nanoid(6), productId, qty }])}
  function removeFromCart(itemId){ setCart(c=>c.filter(i=>i.id!==itemId))}

  // chats (minimal stubs to not break UI anywhere)
  function startChatWith(userId){
    if(!chats[userId]) setChats(prev=>({...prev,[userId]:{messages:[]}}))
  }
  function sendMessage(toUserId, text){
    const msg = { id:nanoid(6), from: currentUser?.id || 'anon', text, ts: Date.now() }
    setChats(prev=>{
      const thread = prev[toUserId] || { messages: [] }
      return { ...prev, [toUserId]: { ...thread, messages: [...thread.messages, msg] } }
    })
  }

  // auth (frontend only)
  function register({ name }){
    const user = { id: nanoid(6), name }
    setUsers(u=>[...u, user])
    setCurrentUser(user)
    return user
  }
  function login({ name }){
    let user = users.find(u=>u.name===name)
    if(!user){ user = { id:nanoid(6), name }; setUsers(u=>[...u, user]) }
    setCurrentUser(user)
    return user
  }
  function logout(){ setCurrentUser(null) }

  // Compatibility: keep signInAsDemo API but open auth modal instead of auto-login
  function signInAsDemo(){ setAuthOpen(true) }

  const value = useMemo(()=> ({
    theme, setTheme,
    locale, setLocale, t,
    currentUser, users,
    signInAsDemo, register, login, logout, authOpen, setAuthOpen,
    products, addProduct, productById,
    cart, addToCart, removeFromCart,
    chats, startChatWith, sendMessage,
  }),[theme, locale, currentUser, users, authOpen, products, cart, chats])

  return <Store.Provider value={value}>{children}</Store.Provider>
}
