
import React, { createContext, useContext, useEffect, useMemo, useState } from 'react'

const messages = {
  en: {
    appTitle: 'Shop',
    settings: 'Settings',
    language: 'Language',
    english: 'English',
    farsi: 'Farsi',
    theme: 'Theme',
    light: 'Light',
    dark: 'Dark',
    account: 'Account',
    signIn: 'Sign In',
    signUp: 'Sign Up',
    signOut: 'Sign Out',
    email: 'Email',
    password: 'Password',
    displayName: 'Display name',
    save: 'Save',
    cancel: 'Cancel',
    uploadProduct: 'Upload product',
    title: 'Title',
    price: 'Price',
    condition: 'Condition',
    category: 'Category',
    description: 'Description',
    image: 'Image',
    create: 'Create',
    notSignedIn: 'Not signed in',
    signedInAs: 'Signed in as',
    new: 'new',
    used: 'used',
    general: 'general',
    uploadSuccess: 'Uploaded successfully',
    uploadError: 'Upload failed',
    chooseFile: 'Choose image...',
    remove: 'Remove',
  },
  fa: {
    appTitle: 'فروشگاه',
    settings: 'تنظیمات',
    language: 'زبان',
    english: 'انگلیسی',
    farsi: 'فارسی',
    theme: 'ظاهر',
    light: 'روشن',
    dark: 'تیره',
    account: 'حساب کاربری',
    signIn: 'ورود',
    signUp: 'ثبت‌نام',
    signOut: 'خروج',
    email: 'ایمیل',
    password: 'رمز عبور',
    displayName: 'نام نمایشی',
    save: 'ذخیره',
    cancel: 'لغو',
    uploadProduct: 'اپلود محصول',
    title: 'عنوان',
    price: 'قیمت',
    condition: 'وضعیت',
    category: 'دسته‌بندی',
    description: 'توضیحات',
    image: 'تصویر',
    create: 'ایجاد',
    notSignedIn: 'وارد نشده‌اید',
    signedInAs: 'وارد شده به عنوان',
    new: 'نو',
    used: 'دست‌دوم',
    general: 'عمومی',
    uploadSuccess: 'با موفقیت آپلود شد',
    uploadError: 'آپلود ناموفق بود',
    chooseFile: 'انتخاب تصویر...',
    remove: 'حذف',
  }
}

const I18nCtx = createContext(null)
export const useI18n = ()=> useContext(I18nCtx)

export default function I18nProvider({ children }){
  const [lang, setLang] = useState(()=> localStorage.getItem('lang') || 'en')
  useEffect(()=>{
    document.documentElement.lang = lang
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr'
    localStorage.setItem('lang', lang)
  }, [lang])
  const t = (key)=> (messages[lang] && messages[lang][key]) || messages.en[key] || key
  const value = useMemo(()=>({ lang, setLang, t }), [lang])
  return <I18nCtx.Provider value={value}>{children}</I18nCtx.Provider>
}
