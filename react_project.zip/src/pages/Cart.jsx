import React from 'react'
import { useStore } from '../contexts/StoreContext.jsx'

export default function Cart(){
  const { cart, products, removeFromCart } = useStore()

  const items = cart.map(i => {
    const p = products.find(p=>p.id===i.productId)
    return { ...i, product: p }
  }).filter(i=>i.product)

  const total = items.reduce((a,i)=> a + i.qty * (i.product?.price || 0), 0)

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Your Cart</h1>
      <div className="space-y-3">
        {items.map(i => (
          <div key={i.id} className="card p-4 flex items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <img src={i.product.image} className="w-20 h-20 object-cover rounded-xl" />
              <div>
                <div className="font-semibold">{i.product.title}</div>
                <div className="text-sm opacity-70">${i.product.price.toFixed(2)} × {i.qty}</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="font-bold">${(i.qty*i.product.price).toFixed(2)}</div>
              <button className="btn btn-ghost" onClick={()=>removeFromCart(i.id)}>Remove</button>
            </div>
          </div>
        ))}
      </div>
      <div className="flex items-center justify-end gap-4">
        <div className="text-lg font-bold">Total: ${total.toFixed(2)}</div>
        <button className="btn btn-primary">Checkout</button>
      </div>
    </div>
  )
}
