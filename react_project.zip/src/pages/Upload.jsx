import React from 'react'
import UploadDrawer from '../components/UploadDrawer.jsx'
import { useStore } from '../contexts/StoreContext.jsx'
import ItemGrid from '../components/ItemGrid.jsx'

export default function Upload(){
  const { products } = useStore()
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Upload Items</h1>
        <UploadDrawer />
      </div>
      <ItemGrid items={products} />
    </div>
  )
}
