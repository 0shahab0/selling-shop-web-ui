import React from 'react'
import { useSearchParams } from 'react-router-dom'
import { useStore } from '../contexts/StoreContext.jsx'
import ItemGrid from '../components/ItemGrid.jsx'

export default function Explore(){
  const { products } = useStore()
  const [sp] = useSearchParams()
  const q = (sp.get('q') || '').toLowerCase()

  const filtered = products.filter(p => {
    const hay = (p.title + ' ' + p.category + ' ' + p.description).toLowerCase()
    return hay.includes(q)
  })

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Explore</h1>
      <ItemGrid items={filtered} />
      {filtered.length===0 && <div className="opacity-70">No results for “{q}”. Try another search.</div>}
    </div>
  )
}
