import React from 'react'
import { useStore } from '../contexts/StoreContext.jsx'
import ItemGrid from '../components/ItemGrid.jsx'
import UploadDrawer from '../components/UploadDrawer.jsx'

export default function Home(){
  const { products } = useStore()
  const featured = products.filter(p=>p.featured)
  return (
    <div className="space-y-10">
      <section className="flex flex-col md:flex-row items-center gap-6 md:gap-12 card p-6 md:p-10">
        <div className="flex-1 space-y-3">
          <h1 className="text-3xl md:text-5xl font-extrabold leading-tight">
            Your multi‑store marketplace, <span className="text-emerald-600">elevated</span>.
          </h1>
          <p className="opacity-80">Upload items with full details, show conditions, and chat privately with buyers — all in one sleek interface.</p>
          <div className="flex gap-3 pt-2">
            <UploadDrawer />
            <a href="/explore" className="btn btn-ghost">Explore</a>
          </div>
        </div>
        <img className="w-full md:w-80 rounded-2xl shadow-lg" src="https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a?q=80&w=1200&auto=format&fit=crop" />
      </section>

      <section className="space-y-4">
        <h2 className="text-xl font-bold">Featured</h2>
        <ItemGrid items={featured.length?featured:products.slice(0,6)} />
      </section>
    </div>
  )
}
