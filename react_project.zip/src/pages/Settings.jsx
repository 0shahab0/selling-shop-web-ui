import React from 'react'
import { useStore } from '../contexts/StoreContext.jsx'

export default function Settings(){
  const { theme, setTheme, currentUser, signInAsDemo, setAuthOpen, logout, locale, setLocale, t } = useStore()
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Settings</h1>

      <div className="card p-4 flex items-center justify-between">
        <div>
          <div className="font-semibold">{t('theme')}</div>
          <div className="text-sm opacity-70">{t('lightOrDark')}</div>
        </div>
        <div className="flex gap-2">
          <button className={"btn " + (theme==='light'?'btn-primary':'btn-ghost')} onClick={()=>setTheme('light')}>{t('light')}</button>
          <button className={"btn " + (theme==='dark'?'btn-primary':'btn-ghost')} onClick={()=>setTheme('dark')}>{t('dark')}</button>
        </div>
      </div>

      <div className="card p-4 flex items-center justify-between">
        <div>
          <div className="font-semibold">{t('language')}</div>
          <div className="text-sm opacity-70">{locale==='fa' ? t('farsi') : t('english')}</div>
        </div>
        <div className="flex gap-2">
          <button className={"btn " + (locale==='en'?'btn-primary':'btn-ghost')} onClick={()=>setLocale('en')}>{t('english')}</button>
          <button className={"btn " + (locale==='fa'?'btn-primary':'btn-ghost')} onClick={()=>setLocale('fa')}>{t('farsi')}</button>
        </div>
      </div>

      <div className="card p-4 flex items-center justify-between">
        <div>
          <div className="font-semibold">{t('account')}</div>
          <div className="text-sm opacity-70">{currentUser ? `${t('signedInAs')} ${currentUser.name}` : t('notSignedIn')}</div>
        </div>
        {!currentUser ? (
          <button className="btn btn-primary" onClick={signInAsDemo}>{t('createAccount')}</button>
        ) : (
          <div className="flex gap-2">
            <button className="btn btn-ghost" onClick={()=>setAuthOpen(true)}>{t('changeAccount')}</button>
            <button className="btn btn-primary" onClick={logout}>Logout</button>
          </div>
        )}
      </div>
    </div>
  )
}
