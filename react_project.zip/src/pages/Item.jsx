import GuardModal from '../components/GuardModal.jsx'
import React from 'react'
import { useParams } from 'react-router-dom'
import { useStore } from '../contexts/StoreContext.jsx'
import ConditionBadge from '../components/ConditionBadge.jsx'

export default function Item(){
  const [warnOpen, setWarnOpen] = React.useState(false)
  const { id } = useParams()
  const {productById, users, addToCart, startChatWith, currentUser, t } = useStore()
  const p = productById(id)
  if(!p) return <div>Item not found.</div>
  const seller = users.find(u=>u.id===p.sellerId)

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
      <div className="card overflow-hidden">
        <img src={p.image} className="w-full h-80 object-cover" />
      </div>
      <div className="space-y-4">
        <div className="flex items-center gap-3">
          <h1 className="text-3xl font-bold">{p.title}</h1>
          <ConditionBadge condition={p.condition} />
        </div>
        <div className="text-emerald-600 text-2xl font-extrabold">${p.price.toFixed(2)}</div>
        <p className="opacity-80">{p.description}</p>
        <div className="flex items-center gap-3 pt-2">
          <img src={seller.avatar} className="w-10 h-10 rounded-full" />
          <div>
            <div className="font-semibold">{seller.name}</div>
            <div className="text-xs opacity-70">Seller</div>
          </div>
        </div>
        <div className="flex gap-3 pt-3">
          <button className="btn btn-primary" onClick={()=> currentUser ? addToCart(p.id,1) : setWarnOpen(true)}>{t('addToCart')}</button>
          <button className="btn btn-ghost" onClick={()=>startChatWith(seller.id)}>{t('chatWithSeller')}</button>
        </div>
      </div>
      <GuardModal open={warnOpen} onClose={()=>setWarnOpen(false)} message={t('warnCart')} />
    </div>
  )
}
