import React from 'react'

export default function About(){
  return (
    <div className="prose dark:prose-invert max-w-none">
      <h1>About GreenMarket</h1>
      <p><strong>GreenMarket</strong> is a slick multi-store marketplace demo focused on great UX. Upload products with full details, label their condition, and chat privately with buyers inside the app.</p>
      <ul>
        <li>Modern UI (Tailwind, dark/light)</li>
        <li>Private chat tabs only show people you’ve messaged</li>
        <li>Local-first: stores data in your browser for demo purposes</li>
      </ul>
      <p>Hook it to a backend later to make it production-ready.</p>
    </div>
  )
}
