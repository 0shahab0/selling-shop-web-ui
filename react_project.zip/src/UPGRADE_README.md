
# Frontend-Only Template (LocalStorage)

## Features
- No backend, no API keys — works out of the box.
- Fake **Sign Up / Sign In** (UI only). Accounts & session saved in `localStorage`.
- **Image uploads** stored as Base64 Data URLs in `localStorage` (persist after refresh).
- **Language switch** English ⇄ Farsi with RTL support.
- Demo data removed — fresh start.

## Run
```bash
npm install
npm run dev
```

> This is a template for UI demos. Do not use the fake auth for real users.
