const translations = {
  en: {
    createAccount: "Create Account",
    login: "Login",
    logout: "Logout",
    changeAccount: "Change Account",
    upload: "Upload",
    uploadNow: "Upload your items now",
    cart: "Cart",
    pleaseLogin: "Please login or sign up before performing this action.",
    marketplaceTitle: "Your multi store marketplace elevated",
    chat: "Chat"
  },
  fa: {
    createAccount: "ساخت حساب",
    login: "ورود",
    logout: "خروج",
    changeAccount: "تغییر حساب",
    upload: "آپلود",
    uploadNow: "همین حالا اقلام خود را آپلود کنید",
    cart: "سبد خرید",
    pleaseLogin: "لطفاً قبل از انجام این کار وارد شوید یا ثبت نام کنید.",
    marketplaceTitle: "بازار چند فروشگاهی شما ارتقا یافته",
    chat: "چت"
  }
};

export default translations;
